#ifndef COTILA_COTILA_H_
#define COTILA_COTILA_H_

#include "voyage/cotila/matrix/math.h"
#include "voyage/cotila/matrix/matrix.h"
#include "voyage/cotila/matrix/operators.h"
#include "voyage/cotila/matrix/utility.h"
#include "voyage/cotila/scalar/math.h"
#include "voyage/cotila/vector/math.h"
#include "voyage/cotila/vector/operators.h"
#include "voyage/cotila/vector/utility.h"
#include "voyage/cotila/vector/vector.h"

#endif // COTILA_COTILA_H_
